#include "smswidget.h"
#include "ui_smswidget.h"
#include <QDebug>
#include <QTextCodec>
#include <QTime>
#include <QVector>

SMSWidget::SMSWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SMSWidget)
{
    ui->setupUi(this);
    ui->Startsmsbtn->setEnabled(true);
    ui->Stopsmsbtn->setEnabled(false);

    ui->statusBar->setText(tr("串口关闭"));
    ui->textEditsmsContent->setText(tr("主人您好!"));
    //初始化读取定时器计时间隔
    timerdly = TIMER_INTERVAL;
    //设置读取计时器
    readTimer = new QTimer(this);
    connect(readTimer, SIGNAL(timeout()), this, SLOT(slotReadMesg()));
}



void SMSWidget::setComboBoxEnabled(bool status)
{
    ui->portNameComboBoxGPS->setEnabled(status);
    ui->baudRateComboBoxGPS->setEnabled(status);
    ui->dataBitsComboBoxGPS->setEnabled(status);
    ui->parityComboBoxGPS->setEnabled(status);
    ui->stopBitsComboBoxGPS->setEnabled(status);
}


SMSWidget::~SMSWidget()
{
    delete ui;
}

void SMSWidget::on_Startsmsbtn_clicked()
{
        QString portName = "/dev/" + ui->portNameComboBoxGPS->currentText();   //获取串口名
        mySmsCom = new Posix_QextSerialPort(portName, QextSerialBase::Polling);
        //这里QextSerialBase::QueryMode应该使用QextSerialBase::Polling

        if(mySmsCom->open(QIODevice::ReadWrite)){
               ui->statusBar->setText(tr("串口打开成功"));
        }else{
               ui->statusBar->setText(tr("串口打开失败"));
            return;
        }
        //设置波特率
        mySmsCom->setBaudRate((BaudRateType)ui->baudRateComboBoxGPS->currentIndex());

        //设置数据位
        mySmsCom->setDataBits((DataBitsType)ui->dataBitsComboBoxGPS->currentIndex());

        //设置校验
        mySmsCom->setParity((ParityType)ui->parityComboBoxGPS->currentIndex());

        //设置停止位
        mySmsCom->setStopBits((StopBitsType)ui->stopBitsComboBoxGPS->currentIndex());
        //设置数据流控制
        mySmsCom->setFlowControl(FLOW_OFF);
        //设置延时
        mySmsCom->setTimeout(TIME_OUT);

        setComboBoxEnabled(false);
        readTimer->start(TIMER_INTERVAL);
        ui->Startsmsbtn->setEnabled(false);
        ui->Stopsmsbtn->setEnabled(true);

}

void SMSWidget::on_Stopsmsbtn_clicked()
{
    mySmsCom->close();
    delete mySmsCom;
    readTimer->stop();
    ui->statusBar->setText(tr("串口关闭"));
    setComboBoxEnabled(true);
    ui->Startsmsbtn->setEnabled(true);
    ui->Stopsmsbtn->setEnabled(false);
}

void SMSWidget::on_btnSendSMS_clicked()
{
    sendAT(mySmsCom,1);
    sleep(5000);
    ConnectPduData(ui->textEditsmsContent->toPlainText(),ui->lineEditcenterphone->text(),ui->lineEditsmsphone->text());
    sendAT(mySmsCom,2);
    sleep(5000);
    sendAT(mySmsCom,3);
}


void SMSWidget::slotReadMesg()
{
    QByteArray temp = mySmsCom->readAll();
    m_qStrInfo.append(temp.data());
    QString strsms=QString(temp);
  if(m_qStrInfo.contains("CMGL")&&m_qStrInfo.contains("OK"))
   {

    strMsgContent= ReadMsg(strsms);
    ui->textBrowsersms->append(strMsgContent);
     qDebug()<<"strsms"<<strsms<<endl;
     qDebug()<<"strMsgContent"<<strMsgContent<<endl;
    }

}

QString SMSWidget::ReadMsg(QString strMsg)
{
    QString strNum;
    char *strdd="Time: ";
    char *strcontent="Content: ";
    QString ctrlouttmp;
    QString strupper;
    int n, nPDULength, i, len ;
    QString strData,strSrc,strDes,nType,strPDULength;
    QString strnumber , strdate, strnumtmp, strdatetmp;
    const char *charPDULength;
    QString messagecontent;

    n = strMsg.findRev(',');

    strPDULength = strMsg.mid(n+1,2);
    charPDULength=strPDULength.latin1();

    nPDULength=(*charPDULength-48)*10;
    nPDULength+=*(charPDULength+1)-48;

    // get the TPDU content
    strData = strMsg.mid(n+23,nPDULength*2);
    // get the mobile phone number
    strnumber=strData.mid(6,14);	//modify 6,12
    // decode the mobile phone number
    len=strnumber.length();
    for(i=0;i<len-2;i=i+2)
    {
    strnumtmp+=strnumber.mid(i+1,1);
    strnumtmp+=strnumber.mid(i,1);
    }
    strnumtmp+=strnumber.mid(i+1,1);
    strNum=strnumtmp;
    // get the date and time
    strdate=strData.mid(24,12);	//22,12
    len=strdate.length();
    // decode the date and time
    for(i=0;i<len;i=i+2)
    {
    strdatetmp+=strdate.mid(i+1,1);
    strdatetmp+=strdate.mid(i,1);
    if(i<4)
        strdatetmp+="-";
    if(i==4)
        strdatetmp+="  ";
    if((i>4)&&(i<10))
        strdatetmp+=":";
    }
    // 2. add the decoded date & time into the message content
    messagecontent+=QString( strdd+strdatetmp+"\n" );
    nType=strData.mid(22,2);//20,2
    // get the content string
    strSrc = strData.mid(40,(nPDULength-19)*2);  	//
    if(nType.find("00",false)>=0)
    // 7 bits decoding
    strDes=Bit7Decode(strSrc);
    else
    // PDU decoding ( it's what we use in this contest )
    strDes=DecToUnicode(strSrc);
    strDes=strDes.lower();
    // 3. add the decoded date & time into the message content
    messagecontent+=QString(strcontent+strDes+"\n");
   //return strDes;
    return messagecontent;
}


QString SMSWidget::DecToUnicode(QString strSrc)
{
    int strlength;
    QString strMsgtmp,str0;
    bool ok;
    QString strMsgout;
    ushort num;
    strlength=strSrc.length();
    const ushort *data;
    for(int i=0;i<strlength;i=i+4)
    {
        str0=strSrc.mid(i,4);
        num=str0.toUShort(&ok,16);
        data=&num;
        strMsgtmp=strMsgtmp.setUnicodeCodes(data,1);
        strMsgout+=strMsgtmp;
    }
    return strMsgout;
}


/************************************************************************/
QString SMSWidget::Bit7Decode(QString &strSrc)
{
    unsigned char pDst[4096];
    char pSrc[4096];
    int i, length;
    int strlength=strSrc.length();
    for(i=0;i<strlength;i++)
    {
        pSrc[i]=strSrc.at(i).latin1();
    }
    for(i=0;  i<strlength;i=i+2)
    {
        char c[2];
        char *p;
        unsigned long t;
        c[0]=pSrc[i];
        c[1]=pSrc[i+1];
        t=strtoul (c,&p,16);
        pDst[i/2]=t;
    }
    length=GSMDecode7bit(pDst,pSrc,strlength/2);
    QString textout=pSrc;
    return textout;
}

/************************************************************************/
int SMSWidget::GSMDecode7bit( const unsigned char *pSrc, char *pDst, int nSrcLength )
{
    int nSrc=0;
    int nDst=0;
    int nByte=0;
    unsigned char nLeft=0;
    while(nSrc<nSrcLength)
    {
        *pDst = ((*pSrc << nByte) | nLeft) & 0x7f;
        nLeft = *pSrc >> (7-nByte);
        pDst++;
        nDst++;
        nByte++;
        if(nByte == 7)
        {
        *pDst = nLeft ;
        pDst++;
        nDst++;
        nByte = 0;
        nLeft = 0;
        }
        pSrc++;
        nSrc++;
    }
    *pDst = 0;
    return nDst;
}




void SMSWidget::on_btnReceivesms_clicked()
{
    sendAT(mySmsCom,1);
    sleep(5000);
    sendAT(mySmsCom,4);
   }


void SMSWidget::on_btn1_clicked()
{

    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '1';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '1';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn2_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '2';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '2';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn3_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '3';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '3';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn4_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '4';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '4';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn5_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '5';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '5';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn6_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '6';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '6';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn7_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '7';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '7';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn8_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '8';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '8';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn9_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '9';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '9';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btn0_clicked()
{
    if(focusflag)
    {
        str= ui->lineEditsmsphone->text();
        str += '0';
      ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str= ui->lineEditcenterphone->text();
        str += '0';
    ui->lineEditcenterphone->setText(str);
    }
}

void SMSWidget::on_btnback_clicked()
{
    if(focusflag)
    {
    str = ui->lineEditsmsphone->text();
    str = str.left(str.length()-1);
    ui->lineEditsmsphone->setText(str);
    }
    else
    {
        str = ui->lineEditcenterphone->text();
        str = str.left(str.length()-1);
        ui->lineEditcenterphone->setText(str);
    }
}
void SMSWidget::sendAT(Posix_QextSerialPort *myCom1 ,int iOrder)
{
    QString qStrCmd;

    switch(iOrder)
    {
    case 1:
    {
        //设置短信格式
        qStrCmd= "AT+CMGF=0\r";
        myCom1->write(qStrCmd.toAscii());
        break;
    }

    case 2:
    {
        //发送短信长度指令
        int iLength=strlen(m_SendCont.toStdString().c_str())/2;
        qDebug()<<"sms======len:"<<iLength;
        qStrCmd=QString("%1%2\r").arg("AT+CMGS=").arg(iLength-9);

        myCom1->write(qStrCmd.toAscii());
        break;
    }

    case 3:
    {
        //发送短信内容指令
        //         myCom->write("0011000D91683166051461F70008011600680065006C006C006F00204F60597D0021000D000A\x01a");
        qDebug()<<"sms======cont:"<<m_SendCont;
        myCom1->write((m_SendCont+"\x01a").toStdString().c_str());
        break;
    }
    case 4:
        //读取未读短信

          qStrCmd= "AT+CMGL=0\r";
          qDebug()<<qStrCmd;
          myCom1->write(qStrCmd.toAscii());
                break;

    default:
        break;
    }
}


QString SMSWidget::stringToUnicode(QString str)
{
    // 这里传来的字符串一定要加tr，main函数里可以加 QTextCodec::setCodecForTr(QTextCodec::codecForLocale());

    //  例如：str=tr("你好");

    const QChar *q;

    QChar qtmp;

    QString str0, strout;

    int num;

    q=str.unicode();

    int len=str.count();

    for(int i=0;i<len;i++)

    {
        qtmp =(QChar)*q++;

        num= qtmp.unicode();

        if(num<255)

            strout+="00"; //英文或数字前加"00"

        str0=str0.setNum(num,16);//变成十六进制数

        strout+=str0;
    }
    return strout;
}



QString SMSWidget::convertMesg(QString qStrMesg)
{
    QTextCodec::setCodecForTr(QTextCodec::codecForLocale());
    qStrMesg = tr(qStrMesg.toStdString().c_str());
    qStrMesg=stringToUnicode(qStrMesg);
    int i=qStrMesg.length()/2;  //内容长度
    QString sHex1;
    sHex1.setNum(i,16);

    if(sHex1.length()==1)
    {
        sHex1="0"+sHex1;
    }

    QString qStrMesgs;
    qStrMesgs = QString("%1%2").arg(sHex1).arg(qStrMesg);

    qDebug()<<qStrMesgs<<endl;
    return qStrMesgs;
}

QString SMSWidget::convertPhone(QString qStrPhone)
{
    int i=qStrPhone.length()+2;     //长度包括86
    sHex.setNum(i,16);      //转成十六进制

    if(sHex.length()==1)
    {
        sHex="0"+sHex;
    }

    if(qStrPhone.length()%2 !=0)  //为奇数位后面加F
    {
        qStrPhone+="F";
    }

    //奇数位偶数位交换
    QString qStrTemp2;
    for(int i=0; i<qStrPhone.length(); i+=2)
    {
        qStrTemp2 +=qStrPhone.mid(i+1,1)+qStrPhone.mid(i,1);
    }

    return qStrTemp2;
}
int SMSWidget::ConnectPduData(QString Msg,QString centerphone,QString smsphone)
{
   QString   centerStr=convertPhone(centerphone);
   QString   smsStr=convertPhone(smsphone);
   QString  smsMsg=convertMesg(Msg);
    //1100：固定，sHex：手机号码的长度，不算＋号，十六进制表示，91：发送到手机为91，发送到小灵通为81
  // 683108502105F0
  QString  qStrTemp2="089168"+centerStr+"1100"+sHex+"9168" +smsStr+"000801"+smsMsg;//"0891683108501905F01100"+sHex+"9168" +qStrTemp2+"000801";
    m_SendCont=qStrTemp2;


    return m_SendCont.length();
}


void SMSWidget::sleep(unsigned int msec)
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void SMSWidget::on_lineEditcenterphone_lostFocus()
{
    focusflag=false;
}

void SMSWidget::on_lineEditsmsphone_lostFocus()
{
    focusflag=true;
}
