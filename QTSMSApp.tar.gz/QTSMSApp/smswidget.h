#ifndef SMSWIDGET_H
#define SMSWIDGET_H

#include <QWidget>
#include "posix_qextserialport.h"
#include <QMessageBox>
#include <QFile>
#include <QTimer>





//延时，TIME_OUT是串口读写的延时
#define TIME_OUT 10
//读取定时器计时间隔,200ms，读取定时器是我们读取串口缓存的延时
#define TIMER_INTERVAL 1000


namespace Ui {
class SMSWidget;
}

class SMSWidget : public QWidget
{
    Q_OBJECT
    
public:
    explicit SMSWidget(QWidget *parent = 0);
    ~SMSWidget();
    void sendAT(Posix_QextSerialPort* NewCom,int iOrder);        //发送指令
    QString convertMesg(QString);    //转换字符串信息变成PDU格式
    QString convertPhone(QString);  //电话号码两两颠倒
    int ConnectPduData(QString,QString,QString);
    void SendSms(QString qStrSend,QString qStrNum);     //发送短信
    QString stringToUnicode(QString str);       //字符串转为unicode
    QString DecToUnicode(QString strSrc);
    QString Bit7Decode(QString &strSrc);
   int GSMDecode7bit( const unsigned char *pSrc, char *pDst, int nSrcLength );
   QString ReadMsg(QString str);
private slots:
    void on_Startsmsbtn_clicked();
    void on_Stopsmsbtn_clicked();
    void on_btnSendSMS_clicked();
    void on_btnReceivesms_clicked();
    void on_btn1_clicked();
    void on_btn2_clicked();
    void on_btn3_clicked();
    void on_btn4_clicked();
    void on_btn5_clicked();
    void on_btn6_clicked();
    void on_btn7_clicked();
    void on_btn8_clicked();
    void on_btn9_clicked();
    void on_btn0_clicked();
    void on_btnback_clicked();
    void on_lineEditcenterphone_lostFocus();
    void on_lineEditsmsphone_lostFocus();
     void slotReadMesg();
private:
    Ui::SMSWidget *ui;
    Posix_QextSerialPort *mySmsCom;//定义读SMS端口
    void setComboBoxEnabled(bool status);
    QString strPhoneNumber;
    QString strCenterNumber;
    void  sleep(unsigned int msec);
    QString m_qStrInfo;     //串口接收的信息
    QString m_SendCont;     //整理好的短信发送内容
     QString sHex;
       QString str;
       bool focusflag;
          QTimer   *readTimer;//定义一个定时器
          int timerdly;
            QString strMsgContent;


};

#endif // SMSWIDGET_H
